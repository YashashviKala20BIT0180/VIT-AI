from datetime import datetime
from flask import Flask, render_template, request
import pandas as pd
from prophet import Prophet

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        selected_date = datetime.strptime(request.form['date'], '%Y-%m-%d').date()

        # Load the historical gold price data
        data = pd.read_csv('data.csv')

        # Preprocess the data
        data['Date'] = pd.to_datetime(data['Date'])
        data.rename(columns={'Date': 'ds', 'Gold Price in INR': 'y'}, inplace=True)

        # Create and train the Prophet model
        model = Prophet()
        model.fit(data)

        # Make prediction for the selected date
        future_date = pd.DataFrame({'ds': [selected_date]})
        prediction = model.predict(future_date)['yhat'].values[0]

        return render_template('index.html', prediction=prediction)
    else:
        return render_template('index.html')

if __name__ == '__main__':
    app.run()
